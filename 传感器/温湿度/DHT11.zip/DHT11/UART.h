#ifndef UART_H
#define UART_H

#include "ioCC2530.h"
#include "string.h"

void InitUart(void);
void UartSendString(unsigned char *Data, int len);
void UartSendByte(unsigned char dat);
void UartPrint(char *str);

#endif